#!/bin/bash
# Created By Basheer Parammal | Copyright 2026 adprocreatives.
# Called by JSX using app.doScript AppleScript. Do not double-click.
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:/Library/Frameworks/Python.framework/Versions/Current/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
KIND="${1:-}"
SOURCE="${2:-}"
if [ "$KIND" != "pptx" ] && [ "$KIND" != "pdf" ]; then
  echo "Choose PPTX or PDF." >&2
  exit 2
fi
if [ ! -f "$SOURCE" ]; then
  echo "Source file not found: $SOURCE" >&2
  exit 2
fi
LOWER_SOURCE="$(printf '%s' "$SOURCE" | tr '[:upper:]' '[:lower:]')"
case "$LOWER_SOURCE" in
  *."$KIND") ;;
  *) echo "Expected a .$KIND file; found $SOURCE" >&2; exit 2 ;;
esac
PYTHON_BIN="$(command -v python3 || true)"
if [ -z "$PYTHON_BIN" ]; then
  echo "Python 3 is required. Install from python.org and restart InDesign." >&2
  exit 3
fi
BASE="$HOME/Library/Application Support/BP_PPTX_PDF_to_InDesign"
ENV_DIR="$BASE/.venv"
LOG="$BASE/prepare.log"
mkdir -p "$BASE"
if [ ! -x "$ENV_DIR/bin/python" ]; then
  if ! "$PYTHON_BIN" -m venv "$ENV_DIR" >"$LOG" 2>&1; then
    echo "Could not create Python environment. Inspect: $LOG" >&2
    exit 4
  fi
fi
if ! "$ENV_DIR/bin/python" -c 'import pptx, PIL, fitz' >/dev/null 2>&1; then
  if ! "$ENV_DIR/bin/python" -m pip install --disable-pip-version-check -r "$HERE/requirements.txt" >"$LOG" 2>&1; then
    echo "Python dependencies failed to install. Internet is required the first time. Inspect: $LOG" >&2
    exit 5
  fi
fi
RUNNER="$HERE/prepare.py"
if [ ! -f "$RUNNER" ]; then
  RUNNER="$HERE/converter_core.pyz"
fi
if [ ! -f "$RUNNER" ]; then
  echo "Missing converter core. Reinstall the full support folder." >&2
  exit 6
fi
if ! "$ENV_DIR/bin/python" "$RUNNER" --kind "$KIND" "$SOURCE" --online-fonts >"$LOG" 2>&1; then
  echo "Could not prepare $KIND source. Inspect: $LOG" >&2
  exit 7
fi
# Path names with spaces and apostrophes are handled by the JSX launcher.
OUT="${SOURCE%.*}_InDesign_Ready/conversion_manifest.json"
if [ ! -s "$OUT" ]; then
  echo "Conversion manifest missing: $OUT. Inspect: $LOG" >&2
  exit 8
fi
printf 'BPCONVERTER_MANIFEST_PATH=%s\n' "$OUT"
