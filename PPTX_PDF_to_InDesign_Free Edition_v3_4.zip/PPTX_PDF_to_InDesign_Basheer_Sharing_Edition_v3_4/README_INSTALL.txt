BASHEER | PPTX + PDF TO INDESIGN - SHARING EDITION v3.4 | macOS
Created By Basheer Parammal · © 2026 adprocreatives.
========================================================================

NEW IN v3.4 - SOURCE-VERIFIED PDF PHOTOGRAPHS + NATIVE VECTOR SHADINGS
- PDF photos/product images are matched to actual embedded source XObjects by
  decoded pixel fingerprint, not by location, so PDF mesh-gradient raster
  previews will not accidentally be extracted or removed.
- Image XObjects are removed ONLY from a unique per-page copy of the PDF.
  No shared XObjects in other pages are modified.
- Each page's original gradient mesh, radial/axial shadings, clipping and
  transparent vector content remains in vector_assets/page_XXX_vector.pdf.
  These are PDF vectors, NOT flattened background PNGs.
- Logos and transparent images with PDF soft masks are corrected to avoid
  opaque black rectangles. Rounded photo clipping is retained when possible.
- Oversized photos used by complex transparency/gradient blend groups remain
  in the linked PDF artwork, because separating them changes the appearance.
- Multi-line PDF text is reconstructed as editable text frames and paragraphs.
- Exact fonts are matched by PostScript name when the font is installed.
- PowerPoint workflow is unchanged.

INSTALL (MAC)
1. Unzip the ZIP.
2. Adobe InDesign > Window > Utilities > Scripts.
3. Right-click User > Reveal in Finder.
4. Copy both:
   PPTX_PDF_to_InDesign_Basheer.jsx
   PPTX_PDF_InDesign_Support/  (entire folder)
5. Remove older converter JSX files and REPLACE the old support folder.
6. Double-click the new JSX and click PPTX or PDF.
7. Select source file, then check the new <source>_InDesign_Ready folder.
Do NOT copy JSON files into Scripts Panel or run a .command file.

MAC REQUIREMENTS
- macOS Adobe InDesign with ExtendScript support.
- Python 3.10+ and network access once to install PyMuPDF, Pillow, python-pptx.
- Allow InDesign AppleScript Automation when macOS requests permission.
- Illustrator is optional, used only to edit linked vector backgrounds.

PDF OUTPUT LAYERS
  01 Editable text and native shapes
  02 Independently movable photos / logos (verified)
  03 Native vector backgrounds and gradients (linked PDF)
  04 Extra separated background images (when safe)
  05 Hidden original page-reference JPGs

FILES NEXT TO YOUR SOURCE PDF
  <source>_Converted.indd and <source>_Converted.idml
  vector_assets/page_001_vector.pdf ... (linked, original native shadings)
  assets/pdf_001_photo_001.png ... (individually linked and clipped images)
  reference/page_001.jpg ... (hidden comparison layer)
  conversion_manifest.json, conversion_report.txt
  fonts_used.txt, font_lookup.txt, font_match_report.txt
  VECTOR_EDITING_README.txt

ILLUSTRATOR / GRADIENT EDITING
- Illustrator can open vector_assets/page_XXX_vector.pdf; choose Save As .AI,
  then relink the InDesign graphic to your AI file via Links panel > Relink.
- The optional Illustrator_Vector_Backgrounds_to_AI.jsx batch-helper can save
  every linked per-page vector PDF as AI when run inside Adobe Illustrator.
- EPS is deliberately not used: it cannot retain all modern PDF transparency.
- Mesh shadings in original PDF do NOT translate losslessly into native
  InDesign two-stop gradient fills. The linked PDF / AI retains the actual
  gradient vectors for external editing in Illustrator.
- If a gradient is rasterized already inside the source PDF, the original
  vector gradient cannot be reconstructed automatically from the PDF alone.

IMPORTANT
- PDF text is editable but may reflow slightly when the original font is
  unavailable or paragraph metrics differ. Font files are never bundled.
- Not every photograph or mask can be separated without loss. Such objects
  remain in the preserved linked PDF and are listed in conversion_report.txt.
- Complex background layers are Illustrator-editable through their PDF link,
  not direct InDesign gradient-handle objects.
- Save/conversion to INDD/IDML must be tested on your installed InDesign.
  Local tests can verify extraction/assets/vector retention only.

CREATOR & LICENSE
This converter's attribution does not claim ownership of source client artwork.
Sharing Edition includes packed script code
for discouraging casual modification, not tamper-proof copy protection.
